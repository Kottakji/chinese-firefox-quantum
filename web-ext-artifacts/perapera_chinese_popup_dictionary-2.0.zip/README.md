# chinese-chrome

Forked from peraperakun/chinese-chrome to convert that project to firefox. Since the new firefox quantum update, the old firefox version stopped working. 
Discussed here: http://www.perapera.org/perapera-firefox/
